
<!DOCTYPE html>
<html lang="pt-BR">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Gerenciamento de Receitas - Lista</title>
    <link rel="stylesheet" href="<?php echo base_url("styles.css") ?>">
</head>

<body>
    <header class="navbar">
        <nav class="nav-container">
            <a href="index.html" class="nav-brand">ReceitasApp</a>
            <ul class="nav-links">
                <li><a href="<?php echo base_url("receitas") ?>" class="active">Lista de Receitas</a></li>
                <li><a href="<?php echo base_url("receitas/inserir") ?>">Nova Receita</a></li>
            </ul>
        </nav>
    </header>

    <main class="container">
        <div class="page-header">
            <h1>Receitas Cadastradas</h1>
            <a href="<?php echo base_url("receitas/inserir") ?>" class="btn btn-primary">+ Nova Receita</a>
        </div>

        <div class="card">
            <table class="data-table">
                <thead>
                    <tr>
                        <th>Código</th>
                        <th>Nome da Receita</th>
                        <th>Ingredientes</th>
                        <th>Modo de Fazer</th>
                        <th class="actions-col">Ações</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach($receitas as $receita) : ?>
                    <tr>
                        <td><?php echo $receita->id ?></td>
                        <td><?php echo $receita->nome ?></td>
                        <td><?php echo $receita->ingredientes ?></td>
                        <td><?php echo $receita->modofazer ?></td>
                        <td class="actions-cell">
                            <a href="<?php echo base_url("receitas/editar/" . $receita->id) ?>" class="btn btn-edit">Editar</a>
                            <a href="<?php echo base_url("receitas/excluir/" . $receita->id) ?>" class="btn btn-delete">Excluir</a>
                        </td>
                    </tr>
                    <?php endforeach ?>
                </tbody>
            </table>
        </div>
    </main>
</body>

</html>
