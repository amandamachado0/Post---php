
<!DOCTYPE html>
<html lang="pt-BR">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Gerenciamento de Receitas - Cadastro</title>
    <link rel="stylesheet" href="<?php echo base_url("styles.css") ?>">
</head>

<body>
    <header class="navbar">
        <nav class="nav-container">
            <a href="index.html" class="nav-brand">ReceitasApp</a>
            <ul class="nav-links">
                <li><a href="<?php echo base_url("receitas") ?>">Lista de Receitas</a></li>
                <li><a href="<?php echo base_url("receitas/inserir") ?>" class="active">Nova Receita</a></li>
            </ul>
        </nav>
    </header>

    <main class="container">
        <div class="page-header">
            <h1>Cadastrar Receita</h1>
        </div>

        <div class="card form-card">
            <p><?php echo $msg ?></p>
            <form method="POST">
                <div class="form-group">
                    <label for="nome">Nome da Receita</label>
                    <input type="text" id="nome" name="nome" value="<?php echo $receita->nome ?? '' ?>" placeholder="Ex: Bolo de Cenoura" required>
                </div>

                <div class="form-group">
                    <label for="ingredientes">Ingredientes</label>
                    <textarea id="ingredientes" name="ingredientes" placeholder="Ex: 3 cenouras, 2 xícaras de farinha..." required><?php echo $receita->ingredientes ?? '' ?></textarea>
                </div>

                <div class="form-group">
                    <label for="modofazer">Modo de Fazer</label>
                    <textarea id="modofazer" name="modofazer" placeholder="Descreva o passo a passo da receita..." required><?php echo $receita->modofazer ?? '' ?></textarea>
                </div>

                <div class="form-actions">
                    <button type="submit" class="btn btn-primary">Salvar</button>
                </div>
            </form>
        </div>
    </main>
</body>

</html>
