
<!DOCTYPE html>
<html lang="pt-BR">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Sabores da Casa - Cadastro de Receita</title>

    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #faf6ef;
            color: #49372c;
            margin: 0;
            padding: 30px;
        }

        .container {
            max-width: 650px;
            margin: 40px auto;
            background: white;
            padding: 30px;
            border-radius: 12px;
        }

        h1 {
            color: #a34f32;
        }

        label {
            display: block;
            margin-top: 20px;
            margin-bottom: 8px;
            font-weight: bold;
        }

        input, textarea {
            width: 100%;
            padding: 12px;
            border: 1px solid #ddd;
            border-radius: 6px;
            box-sizing: border-box;
            font-family: Arial, sans-serif;
        }

        textarea {
            min-height: 150px;
            resize: vertical;
        }

        button {
            margin-top: 20px;
            padding: 12px 22px;
            background: #a34f32;
            color: white;
            border: none;
            border-radius: 6px;
            cursor: pointer;
        }

        a {
            color: #a34f32;
        }
    </style>
</head>

<body>

    <main class="container">

        <h1><?= isset($post) ? 'Editar Receita' : 'Cadastrar Receita' ?></h1>

        <p><?= esc($msg ?? '') ?></p>

        <form method="post" enctype="multipart/form-data"> para enviar arquivos pelo formulário

            <label for="titulo">Nome da Receita</label>
            <input
                type="text"
                id="titulo"
                name="titulo"
                value="<?= esc($post->titulo ?? '') ?>"
                placeholder="Ex: Bolo de Cenoura"
                required
            >

            <label for="conteudo">Ingredientes e Modo de Preparo</label>
            <textarea
                id="conteudo"
                name="conteudo"
                placeholder="Informe os ingredientes e explique o modo de preparo..."
                required
            ><?= esc($post->conteudo ?? '') ?></textarea>

            <label for="imagem">Foto da Receita</label>

            <input type="file" id="imagem" name="imagem" accept="image/*" >

            <button type="submit">Salvar Receita</button>

        </form>

        <p><a href="<?= base_url('painel/posts') ?>">Voltar ao painel</a></p>

    </main>

</body>
</html>
