
<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Sabores da Casa | Blog de Receitas</title>

    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }

        body {
            font-family: Arial, sans-serif;
            background-color: #faf6ef;
            color: #49372c;
        }

        header {
            background-color: #fffdf9;
            padding: 25px 8%;
            display: flex;
            justify-content: space-between;
            align-items: center;
            border-bottom: 1px solid #eee2d4;
        }

        header h1 {
            color: #a34f32;
            font-size: 28px;
        }

        nav a {
            text-decoration: none;
            color: #49372c;
            margin-left: 25px;
            font-weight: bold;
        }

        nav a:hover {
            color: #a34f32;
        }

        .banner {
            background-color: #e9d2bb;
            text-align: center;
            padding: 65px 20px;
        }

        .banner h2 {
            font-size: 38px;
            margin-bottom: 15px;
            color: #713d29;
        }

        .banner p {
            font-size: 17px;
            color: #654c3d;
        }

        .container {
            width: 85%;
            max-width: 1100px;
            margin: 50px auto;
        }

        .container h2 {
            font-size: 28px;
            margin-bottom: 25px;
            color: #713d29;
        }

       .receitas {
        display: grid;
        grid-template-columns: repeat(3, 1fr);
        gap: 25px;
        }

        .card {
        background-color: white;
        border-radius: 12px;
        padding: 20px;
        box-shadow: 0 3px 12px rgba(0,0,0,0.07);
        overflow: hidden;
        }

        .card img {
        width: 100%;
        height: 220px;
        object-fit: cover;
        object-position: center;
        border-radius: 8px;
        margin-bottom: 18px;
        }

       .card h3 {
        color: #8b3e25;
        font-size: 26px;
        font-weight: bold;
        margin-bottom: 15px;
        line-height: 1.3;
        }
        .card p {
            color: #76675c;
            margin-bottom: 20px;
        }

        .card a {
            display: inline-block;
            background-color: #a34f32;
            color: white;
            text-decoration: none;
            padding: 10px 18px;
            border-radius: 6px;
        }

        .card a:hover {
            background-color: #713d29;
        }

        .vazio {
            background-color: white;
            padding: 30px;
            border-radius: 10px;
            text-align: center;
        }

        footer {
            background-color: #49372c;
            color: white;
            text-align: center;
            padding: 25px;
            margin-top: 60px;
        }
        @media (min-width: 601px) and (max-width: 900px) {
        .receitas {
        grid-template-columns: repeat(2, 1fr);
        }
        }
        @media (max-width: 600px) {
            .receitas {
        grid-template-columns: 1fr;
        }
            header {
                flex-direction: column;
                gap: 15px;
            }

            nav a {
                margin: 0 8px;
            }

            .banner h2 {
                font-size: 28px;
            }
        }
    </style>
</head>

<body>

    <header>
        <h1>Sabores da Casa</h1>

        <nav>
            <a href="<?= base_url('/') ?>">Início</a>
            <a href="<?= base_url('painel/posts') ?>">Painel</a>
        </nav>
    </header>

    <section class="banner">
        <h2>Receitas feitas com carinho!</h2>
        <p>Descubra novos sabores e encontre inspiração para sua cozinha.</p>
    </section>

    <main class="container">

        <h2>Últimas Receitas</h2>

        <div class="receitas">

            <?php if (!empty($posts)): ?>

                <?php foreach ($posts as $post): ?>

                    <div class="card">

                        <?php if (!empty($post->imagem)): ?>
                            <img src="<?= base_url('uploads/receitas/' . $post->imagem) ?>" alt="<?= esc($post->titulo) ?>">
                        <?php endif; ?>

                        <h3>
                            <?= esc($post->titulo) ?>
                        </h3>

                        <p>
                            Confira essa receita e descubra como prepará-la!
                        </p>

                        <a href="<?= base_url('posts/visualizar/' . $post->id) ?>">
                            Ver receita
                        </a>

                    </div>

                <?php endforeach; ?>

            <?php else: ?>

                <div class="vazio">
                    <h3>Nenhuma receita cadastrada ainda!</h3>
                    <p>Em breve teremos novidades deliciosas por aqui.</p>
                </div>

            <?php endif; ?>

        </div>

    </main>

    <footer>
        <p>Sabores da Casa &copy; <?= date('Y') ?> - Todos os direitos reservados.</p>
    </footer>

</body>
</html>
