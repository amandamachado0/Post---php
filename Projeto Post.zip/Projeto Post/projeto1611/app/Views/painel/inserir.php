
<!DOCTYPE html>
<html lang="pt-BR">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Cadastro de Receitas</title>
</head>

<body>

    <h1>
        <?= isset($post) ? 'Editar Receita' : 'Nova Receita' ?>
    </h1>

    <p><?= $msg ?></p>

    <form method="post">

        <label for="titulo">Nome da Receita:</label>
        <br>

        <input
            type="text"
            name="titulo"
            id="titulo"
            value="<?= isset($post) ? esc($post->titulo) : '' ?>"
            required
        >

        <br><br>

        <label for="conteudo">Ingredientes e Modo de Preparo:</label>
        <br>

        <textarea
            name="conteudo"
            id="conteudo"
            rows="10"
            cols="50"
            required
        ><?= isset($post) ? esc($post->conteudo) : '' ?></textarea>

        <br><br>

        <button type="submit">Salvar Receita</button>

    </form>

    <br>

    <a href="<?= base_url('painel/posts') ?>">Voltar para receitas</a>

</body>

</html>
