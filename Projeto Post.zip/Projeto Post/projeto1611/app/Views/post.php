
<!DOCTYPE html>
<html lang="pt-BR">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Gerenciamento de Receitas - Lista</title>

    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #faf6ef;
            color: #49372c;
            margin: 0;
            padding: 0;
        }

        .navbar {
            background-color: #fffdf9;
            border-bottom: 1px solid #eee2d4;
            padding: 20px 8%;
        }

        .nav-container {
            display: flex;
            justify-content: space-between;
            align-items: center;
        }

        .nav-brand {
            color: #a34f32;
            font-size: 24px;
            font-weight: bold;
            text-decoration: none;
        }

        .nav-links {
            display: flex;
            gap: 25px;
            list-style: none;
            margin: 0;
            padding: 0;
        }

        .nav-links a {
            color: #49372c;
            text-decoration: none;
            font-weight: bold;
        }

        .nav-links a:hover {
            color: #a34f32;
        }

        .container {
            width: 85%;
            max-width: 1100px;
            margin: 40px auto;
        }

        .page-header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 25px;
        }

        h1 {
            color: #a34f32;
        }

        .card {
            background-color: white;
            padding: 25px;
            border-radius: 12px;
            box-shadow: 0 3px 12px rgba(0,0,0,0.07);
            overflow-x: auto;
        }

        .btn {
            display: inline-block;
            padding: 10px 16px;
            border-radius: 6px;
            text-decoration: none;
            font-weight: bold;
            border: none;
            cursor: pointer;
        }

        .btn-primary {
            background-color: #a34f32;
            color: white;
        }

        .btn-primary:hover {
            background-color: #713d29;
        }

        .btn-edit {
            background-color: #e9d2bb;
            color: #713d29;
        }

        .btn-delete {
            background-color: #a34f32;
            color: white;
        }

        .data-table {
            width: 100%;
            border-collapse: collapse;
        }

        .data-table th,
        .data-table td {
            padding: 15px;
            border-bottom: 1px solid #eee2d4;
            text-align: left;
        }

        .data-table th {
            background-color: #e9d2bb;
            color: #713d29;
        }

        .imagem {
            width: 100px;
            height: 75px;
            object-fit: cover;
            border-radius: 8px;
        }

        .actions-cell {
            white-space: nowrap;
        }

        .actions-cell a {
            margin-right: 5px;
        }

        .voltar {
            display: inline-block;
            margin-top: 25px;
            color: #a34f32;
            text-decoration: none;
            font-weight: bold;
        }

        @media (max-width: 600px) {
            .nav-container,
            .page-header {
                flex-direction: column;
                align-items: flex-start;
                gap: 15px;
            }

            .nav-links {
                gap: 15px;
            }

            .container {
                width: 92%;
            }
        }
    </style>
</head>

<body>

    <header class="navbar">
        <nav class="nav-container">
            <a href="<?= base_url('/') ?>" class="nav-brand">Sabores da Casa</a>

            <ul class="nav-links">
                <li><a href="<?= base_url('/') ?>">Início</a></li>
                <li><a href="<?= base_url('painel/posts') ?>">Receitas Cadastradas</a></li>
            </ul>
        </nav>
    </header>

    <main class="container">

        <div class="page-header">
            <h1>Receitas Cadastradas</h1>

            <a href="<?= base_url('posts/inserir') ?>" class="btn btn-primary">
                + Nova Receita
            </a>
        </div>

        <div class="card">

            <table class="data-table">

                <thead>
                    <tr>
                        <th>Código</th>
                        <th>Imagem</th>
                        <th>Nome da Receita</th>
                        <th>Conteúdo</th>
                        <th class="actions-col">Ações</th>
                    </tr>
                </thead>

                <tbody>

                    <?php if (!empty($posts)): ?>

                        <?php foreach ($posts as $post): ?>

                            <tr>
                                <td><?= esc($post->id) ?></td>

                                <td>
                                    <?php if (!empty($post->imagem)): ?>
                                        <img
                                            src="<?= base_url('uploads/receitas/' . $post->imagem) ?>"
                                            alt="<?= esc($post->titulo) ?>"
                                            class="imagem"
                                        >
                                    <?php else: ?>
                                        Sem imagem
                                    <?php endif; ?>
                                </td>

                                <td><?= esc($post->titulo) ?></td>

                                <td><?= esc($post->conteudo) ?></td>

                                <td class="actions-cell">

                                    <a href="<?= base_url('posts/editar/' . $post->id) ?>" class="btn btn-edit">
                                        Editar
                                    </a>

                                    <a
                                        href="<?= base_url('posts/excluir/' . $post->id) ?>"
                                        class="btn btn-delete"
                                        onclick="return confirm('Deseja realmente excluir esta receita?')"
                                    >
                                        Excluir
                                    </a>

                                </td>
                            </tr>

                        <?php endforeach; ?>

                    <?php else: ?>

                        <tr>
                            <td colspan="5">Nenhuma receita cadastrada.</td>
                        </tr>

                    <?php endif; ?>

                </tbody>

            </table>

        </div>

        <a href="<?= base_url('/') ?>" class="voltar">
            Voltar ao blog
        </a>

    </main>

</body>
</html>
