<?php

namespace App\Controllers;

class Posts extends BaseController
{
    public function index()
    {
        $postModel = model('PostModel');
        $dados['posts'] = $postModel->findAll();

        return view('post', $dados);
    }

    public function inserir()
    {
        $dados['msg'] = "";

        // verifica se foi feita uma requisição POST
        if($this->request->is('post')) {
            $postModel = model('PostModel');
            $dadosPost = $this->request->getPost();

            // recebe a imagem enviada pelo formulário
            $imagem = $this->request->getFile('imagem');

            if($imagem && $imagem->getError() != UPLOAD_ERR_NO_FILE) {

                if(!$imagem->isValid()) {
                    $dados['msg'] = "Erro ao enviar imagem";
                    return view('post_form', $dados);
                }

                $tiposPermitidos = ['image/jpeg', 'image/png', 'image/gif', 'image/webp'];

                if(!in_array($imagem->getMimeType(), $tiposPermitidos)) {
                    $dados['msg'] = "Formato de imagem não permitido";
                    return view('post_form', $dados);
                }

                if($imagem->getSize() > 2 * 1024 * 1024) {
                    $dados['msg'] = "A imagem deve ter no máximo 2 MB";
                    return view('post_form', $dados);
                }

                $nomeImagem = $imagem->getRandomName();

                $imagem->move(FCPATH . 'uploads/receitas', $nomeImagem);

                $dadosPost['imagem'] = $nomeImagem;
            }

            if($postModel->insert($dadosPost)) {
                // sucesso. redireciona para a lista de receitas
                return redirect()->to('painel/posts');
            } else {
                // erro
                $dados['msg'] = "Erro ao salvar receita";
            }
        }

        return view('post_form', $dados);
    }

    public function editar($id)
    {
        $postModel = model('PostModel');
        $dados['post'] = $postModel->find($id);
        $dados['msg'] = '';

        if(!$dados['post']) {
            throw \CodeIgniter\Exceptions\PageNotFoundException::forPageNotFound();
        }

        // verifica se foi feita uma requisição POST
        if($this->request->is('post')) {
            $dadosPost = $this->request->getPost();

            // recebe uma nova imagem, caso tenha sido selecionada
            $imagem = $this->request->getFile('imagem');

            if($imagem && $imagem->getError() != UPLOAD_ERR_NO_FILE) {

                if(!$imagem->isValid()) {
                    $dados['msg'] = "Erro ao enviar imagem";
                    return view('post_form', $dados);
                }

                $tiposPermitidos = ['image/jpeg', 'image/png', 'image/gif', 'image/webp'];

                if(!in_array($imagem->getMimeType(), $tiposPermitidos)) {
                    $dados['msg'] = "Formato de imagem não permitido";
                    return view('post_form', $dados);
                }

                if($imagem->getSize() > 2 * 1024 * 1024) {
                    $dados['msg'] = "A imagem deve ter no máximo 2 MB";
                    return view('post_form', $dados);
                }

                $nomeImagem = $imagem->getRandomName();

                $imagem->move(FCPATH . 'uploads/receitas', $nomeImagem);

                $dadosPost['imagem'] = $nomeImagem;
            }

            if($postModel->update($id, $dadosPost)) {
                // sucesso. redireciona para a lista de receitas
                return redirect()->to('painel/posts');
            } else {
                // erro
                $dados['msg'] = "Erro ao salvar receita";
            }
        }

        return view('post_form', $dados);
    }

    public function excluir($id)
    {
        $postModel = model('PostModel');
        $postModel->delete($id);

        return redirect()->to('painel/posts');
    }

    public function visualizar($id)
    {
        $postModel = model('PostModel');
        $dados['post'] = $postModel->find($id);

        if(!$dados['post']) {
            throw \CodeIgniter\Exceptions\PageNotFoundException::forPageNotFound();
        }

        return view('post_visualizar', $dados);
    }

    public function teste()
    {
        $postModel = new \App\Models\PostModel();

        $novoPost = [
            'titulo'   => "Bolo de Cenoura",
            'conteudo' => "Ingredientes: cenoura, ovos, açúcar e farinha. Modo de preparo: bata os ingredientes, coloque em uma forma e asse até dourar."
        ];

        if($postModel->insert($novoPost)) {
            echo 'Receita salva com sucesso!';
        } else {
            echo 'Erro ao salvar receita <br />';
            print_r($postModel->errors());
        }
    }
}
