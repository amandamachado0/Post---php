-- phpMyAdmin SQL Dump
-- version 5.2.3
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1:3306
-- Tempo de geração: 17/11/2026 às 23:56
-- Versão do servidor: 10.4.32-MariaDB
-- Versão do PHP: 8.3.28

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Banco de dados: `posts_receitas`
--

-- --------------------------------------------------------

--
-- Estrutura para tabela `posts`
--

DROP TABLE IF EXISTS `posts`;
CREATE TABLE IF NOT EXISTS `posts` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `titulo` varchar(255) NOT NULL,
  `conteudo` text NOT NULL,
  `created_at` datetime DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL,
  `imagem` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Despejando dados para a tabela `posts`
--

INSERT INTO `posts` (`id`, `titulo`, `conteudo`, `created_at`, `updated_at`, `imagem`) VALUES
(1, 'Pudim de pao', 'Ingredientes (12 porções)\r\novo\r\n4 ovos\r\nLeitBom\r\n1 lata de leite condensado\r\npão francês\r\n3 pães (francês)\r\nmargarina\r\n1 colher de margarina\r\nLeitBom\r\n2 medidas de leite (medir na lata de leite condensado)\r\naçúcar\r\n1/2 xícara de açúcar\r\naçúcar\r\n1 xícara de açúcar para a calda\r\n\r\n\r\n\r\n1\r\nMisture todos os ingredientes no liquidificador e bata bem.\r\n\r\n2\r\nReserve.\r\n\r\n3\r\nEm uma forma própria para pudim derreta o açúcar para fazer a calda, espere endurecer um pouco e coloque o líquido que está no liquidificador.\r\n\r\n4\r\nLeve ao fogo por uns 35 minutos ou até você enfiar um garfo e ele sair limpo.', '2026-11-17 23:14:56', '2026-11-17 23:42:57', '1794958977_24bf74e93d7ee882a04b.jpg');
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
